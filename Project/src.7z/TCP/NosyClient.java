package TCP;

import java.io.*;
import java.net.*;
import java.util.*;

public class NosyClient 
{
	
	public static void main (String args[]) throws Exception {
		
		if (args.length != 2) 
		{
			System.out.println("Required arguments: <host> <port>");
			return;
		}
		
		String host = args[0];
		int serverport = Integer.parseInt(args[1]);
		System.out.print("Enter command > ");
		
		Scanner in = new Scanner(System.in);
		
		String clientCommand = in.next();
		String responsetoCommand = "";
	
		in.close();
		
		Socket clientSocket = new Socket(host, serverport);
		DataOutputStream outToServer =
				new DataOutputStream(clientSocket.getOutputStream());
		
		BufferedReader inFromServer = new BufferedReader (new
				InputStreamReader(clientSocket.getInputStream()));
		
		outToServer.writeBytes(clientCommand + "\n");
		
		responsetoCommand = inFromServer.readLine();
		
		System.out.println(responsetoCommand);
		
		clientSocket.close();
		

	}
}
