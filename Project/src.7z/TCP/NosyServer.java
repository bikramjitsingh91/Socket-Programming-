package TCP;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.TimeZone;

public class NosyServer {

	public static void main (String argv[]) throws Exception 
	{
		if (argv.length != 1) 
		{
			System.out.println("Required arguments: port");
			return;
		}
		
		String clientCommand;
		String responsetoCommand = "";
		
		ServerSocket welcomeSocket = new ServerSocket(5555);
		
		while(true)
		{
			Socket connectionSocket = welcomeSocket.accept();
			
			BufferedReader inFromClient = new BufferedReader (new
					InputStreamReader(connectionSocket.getInputStream()));
			
			DataOutputStream outToClient =
					new DataOutputStream(connectionSocket.getOutputStream());
			
			clientCommand = inFromClient.readLine();
			if(clientCommand.equals("date"))
			{
				responsetoCommand = new Date().toString();
			}
			else if(clientCommand.equals("timezone")){
				responsetoCommand = TimeZone.getDefault().toString();
			}
			else if(clientCommand.equals("OSname")){
				responsetoCommand = System.getProperty("os.name");
			}
			else if(clientCommand.equals("OSversion")){
				responsetoCommand = System.getProperty("os.version");
			}
			else if(clientCommand.equals("user.name")){
				responsetoCommand = System.getProperty("os.name");
			}
			else
			{
				System.exit(0);;
			}
			outToClient.writeBytes(responsetoCommand + "\n");
			//outToClient.writeBytes("HelloClient");
			connectionSocket.close();
		}
	}
	
	

}
