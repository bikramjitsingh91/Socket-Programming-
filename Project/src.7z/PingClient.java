import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Scanner;


public class PingClient {

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		
		// Get command line argument.
		if (args.length != 1) 
		{
			System.out.println("Required arguments: port");
			return;
		}
		
		//reading the port, client will use from the command line argument provided by user
		int port = Integer.parseInt(args[0]);
		
		/*Instructions for the user how to run the client code*/
		System.out.println("Comand Syntax: ping <destination addr> <destination port> \n"
				+ "Use CTRL^C to quit");
		
		System.out.print("ping ");
		Scanner in = new Scanner(System.in);
		
		//Get the server name client wants to connect to, and post number of the server
		
		String host = in.next();
		int serverport = in.nextInt();
		in.close();
		
		/*Creating sending and receiving buffer to store the date which will be sent to server 
		and the data which received from server*/
		
		byte[] sendData = new byte[1204];
		byte[] receiveData = new byte[1204];
		
		//Create UDP socket with the port number provided by the user in the command line argument
		DatagramSocket clientSocket = new DatagramSocket(port);
		
		//Get the IP address of the host specified by the user
		InetAddress IPAddress = InetAddress.getByName(host);
		
		//Initialize the time value which will be by 
		int timeout = 1000;
		
		for(int seq = 0; seq < 10; seq ++)
		{
			
			Date timestamp = new Date();
			String sentence = "PING " + seq + " " + timestamp;
			
			sendData = sentence.getBytes();
			DatagramPacket sendPacket =	new DatagramPacket(sendData, sendData.length, 
						IPAddress, serverport);
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			clientSocket.send(sendPacket);
			
			clientSocket.setSoTimeout(timeout);
			
			try
			{
				clientSocket.receive(receivePacket);		
				String recived = new String(receivePacket.getData());
				String recaddrr = receivePacket.getAddress().toString();
				System.out.println("Received from : " + recaddrr + " " +recived.trim());
			}
			catch(SocketTimeoutException e)
			{
				System.out.println("PING " + seq + " Request timed out.");
				continue;
			}
			
		}
		clientSocket.close();
				
	}

}
